package unit;

public enum State {Walk, Idle, Attack, BeAttacked, Dead}
