package castle;
public class Castle {
    int HP = 10000;

    public int getHP() { return this.HP; }
    public void setHP(int HP) {
        this.HP = HP;
    }

}
