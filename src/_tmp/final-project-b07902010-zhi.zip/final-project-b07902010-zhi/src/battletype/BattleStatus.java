package battletype;

public enum BattleStatus {
    battleContinue, win, lose;
}
