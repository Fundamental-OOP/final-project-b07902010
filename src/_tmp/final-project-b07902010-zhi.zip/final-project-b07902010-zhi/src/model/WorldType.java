package model;

public enum WorldType {
    MainMenu, Level, None;
}
