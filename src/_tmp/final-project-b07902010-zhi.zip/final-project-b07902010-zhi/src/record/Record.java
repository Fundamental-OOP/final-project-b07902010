package record;

public class Record {
    
    String highestLevelName;
    String nextLevelName;
    public Record(String highestLevelName){
        this.highestLevelName = highestLevelName;

    }
    public String getHighestLevelName(){
        return highestLevelName;
    }
}
